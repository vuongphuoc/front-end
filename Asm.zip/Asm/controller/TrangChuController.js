window.TrangChuController = function($scope){
    $scope.title="KỊCH BẢN MẪU QUY TRÌNH NHẬN ĐẶT PHÒNG KHÁCH SẠN QUA ĐIỆN THOẠI CHO LỄ TÂN ";
    $scope.leTan="Lễ tân cần lấy thông tin gì từ khách hàng để đặt phòng khách sạn? ";
    $scope.kichBan="Kịch bản mẫu quy trình nhận đặt phòng khách sạn qua điện thoại ";
    $scope.monAn="Các món ăn có ở khách sạn kèm theo khi đặt phòng";
    $scope.anh="KỊCH BẢN MẪU QUY TRÌNH NHẬN ĐẶT PHÒNG KHÁCH SẠN QUA ĐIỆN THOẠI CHO LỄ TÂN ";
}